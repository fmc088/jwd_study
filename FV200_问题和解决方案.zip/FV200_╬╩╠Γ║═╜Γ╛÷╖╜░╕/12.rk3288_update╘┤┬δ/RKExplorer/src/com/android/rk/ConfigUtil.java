package com.android.rk;

public class ConfigUtil {

	public static boolean NOT_USE_SDCRAD = false;
	
	public static boolean USE_STORAGEMANAGER_TO_FILL = false;
}
